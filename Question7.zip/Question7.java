import java.util.Scanner;
class Question7{
	public static void main(String[] args){
		int x,n;
		double p;
		double sum=0;
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter the number aka the x: ");
		x=Integer.parseInt(reader.nextLine());
		System.out.println("Enter the number till where you want powers: ");
		n=Integer.parseInt(reader.nextLine());
		System.out.println("Enteres NO is: "+x);
		for(int i=1;i<=n;i++)
		{
			p=Math.pow(x,i);
			System.out.println(p);
			sum=sum+p;
		}
		System.out.println("The total is "+sum);
	}
}