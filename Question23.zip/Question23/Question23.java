public class Question23{
	public static void main(String args[]){
		Cuboid obj=new Cuboid();
		obj.Get_RecDetails();
		obj.Calc_AreaRec();
		obj.Get_CubeDetails();
		obj.Calc_Area();
	}
}