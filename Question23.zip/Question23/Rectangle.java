import java.util.Scanner;
class Rectangle{
	
	int area;
	int l,b;
	
	public void Get_RecDetails()
	{
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter length : ");	
		l=Integer.parseInt(reader.nextLine());
		System.out.println("Enter breadth : ");
		b=Integer.parseInt(reader.nextLine());
	}
	public void Calc_AreaRec()
	{
		area=l*b;
		System.out.println("The area of the rectangle is: "+area);
	}
}