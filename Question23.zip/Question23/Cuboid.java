import java.util.Scanner;
class Cuboid extends Rectangle{
	
	int h;
	
	public void Get_CubeDetails()
	{
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter height : ");	
		h=Integer.parseInt(reader.nextLine());
	}
	public void Calc_Area()
	{
		area=l*b*h;
		System.out.println("The area of the Area is: "+area);
	}
}