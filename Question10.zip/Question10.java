import java.util.Scanner;
class Question10{
	public static void main(String[] args){
		Scanner reader=new Scanner(System.in);
		int i,n1,tmp=0,j,n2;
		boolean equalOrNot = true;
		System.out.println("Enter Array1 size: ");
		n1=Integer.parseInt(reader.nextLine());
		System.out.println("Enter Array2 size: ");
		n2=Integer.parseInt(reader.nextLine());
		int arr1[]=new int[n1];
		int arr2[]=new int[n2];
		System.out.println("Enter Array1 elements: ");
		for(i=0;i<arr1.length;i++)
		{	
			arr1[i]=Integer.parseInt(reader.nextLine());
		}
		System.out.println("Array1 elements are: ");
		for(i=0;i<arr1.length;i++)
		{	
			System.out.println(arr1[i]);
		}
		System.out.println("Enter Array2 elements: ");
		for(j=0;j<arr2.length;j++)
		{	
			arr2[j]=Integer.parseInt(reader.nextLine());
		}
		for(j=0;j<arr2.length;j++)
		{	
			System.out.println(arr2[j]);
		}
		
         
        	if(arr1.length == arr2.length)
        	{
           		for (i = 0; i < arr1.length; i++)
            		{
                			if(arr1[i] != arr2[i])
                			{
                    			equalOrNot = false;
				break;
                			}	
				
		}
	}
         
        	if (equalOrNot)
        	{
           	 	System.out.println("Two Arrays Are Equal");
        	}
        	else
        	{
            		System.out.println("Two Arrays Are Not equal");
        	}
}
}