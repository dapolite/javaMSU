import java.util.Scanner;
class Question8{
	public static void main(String[] args){
		Scanner reader=new Scanner(System.in);
		int i,n,tmp,rep,pos;
		System.out.println("Enter Array size: ");
		n=Integer.parseInt(reader.nextLine());
		int arr[]=new int[n];
		System.out.println("Enter Array elements: ");
		for(i=0;i<arr.length;i++)
		{	
			arr[i]=Integer.parseInt(reader.nextLine());
		}
		System.out.println("Array elements are: ");
		for(i=0;i<arr.length;i++)
		{	
			System.out.println(arr[i]);
		}
		System.out.println("Enter the element you wanna replace: ");
		rep=Integer.parseInt(reader.nextLine());
		System.out.println("Enter the position at which you wanna replace: ");
		pos=Integer.parseInt(reader.nextLine());
		for(i=0;i<pos;i++)
		{	
			arr[pos]=rep;
		}
		System.out.println("New Array elements are: ");
		for(i=0;i<arr.length;i++)
		{	
			System.out.println(arr[i]);
		}
		
	}
}