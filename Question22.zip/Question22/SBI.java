class SBI extends Account{
	SBI()
	{
		rate=30;
	}

	public void RateOfInterest()
	{
		simple_interest = (principal_amt * rate * time) / 100.0;
		System.out.println("The simple interest for the given amount of SBI is: "+simple_interest);
	}
}