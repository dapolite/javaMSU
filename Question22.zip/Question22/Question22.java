public class Question22{
	public static void main(String args[]){
		Account ac=new Account();
		SBI s=new SBI();  
		ICICI i=new ICICI();  
		AXIS a=new AXIS();
		ac=s;
		ac.Get_Data();
		ac.RateOfInterest();
		ac=i;
		ac.Get_Data();
		ac.RateOfInterest();
		ac=a;
		ac.Get_Data();
		ac.RateOfInterest();
	}
}