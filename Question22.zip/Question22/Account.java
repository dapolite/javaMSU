import java.util.Scanner;
class Account{
	int time;
	double principal_amt, rate, simple_interest;
	
	Account()
	{
		principal_amt=0;
		rate=0;
		time=0;
	}

	public void Get_Data()
	{
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter principal amount: ");
		principal_amt=reader.nextFloat();
		System.out.println("Enter time: ");
		time=reader.nextInt();
	}

	public void RateOfInterest()
	{
		simple_interest = (principal_amt * rate * time) / 100.0;
		System.out.println("The simple interest for the given amount of AXIS is: "+simple_interest);
	}
}