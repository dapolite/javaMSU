class AXIS extends Account{

	AXIS()
	{
		rate=10;
	}
	public void RateOfInterest()
	{
		simple_interest = (principal_amt * rate * time) / 100.0;
		System.out.println("The simple interest for the given amount of AXIS is: "+simple_interest);
	}
}