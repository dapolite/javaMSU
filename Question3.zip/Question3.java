import java.util.Scanner;
class Question3{
	public static void main(String[] args){
		int a,d,u,t;
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter Distance: ");
		d=Integer.parseInt(reader.nextLine());
		System.out.println("Distance: "+d);
		System.out.println("Enter Acceleration: ");
		a=Integer.parseInt(reader.nextLine());
		System.out.println("Acceleration: "+a);
		System.out.println("Enter Velocity: ");
		u=Integer.parseInt(reader.nextLine());
		System.out.println("Velocity: "+u);
		System.out.println("Enter Time: ");
		t=Integer.parseInt(reader.nextLine());
		System.out.println("Time: "+t);
		int res=d=u*t+1/2*a*t*t;
		System.out.println("Result: "+res);
	}
}