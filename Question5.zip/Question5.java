import java.util.Scanner;
class Question5{
    public static void main(String args[]){
      int op;
      int num1;
      int num2;
      Scanner reader=new Scanner(System.in);
      System.out.println("Menu for Operator thingy: ");
      System.out.println("Enter your Choice I guess \t1.Bitwise Operator \t2.Bitwise Complement operator \t3.Boolean complement operator \t4.Short Circuit Operator");
      System.out.println("Enter your choice: ");
      op=Integer.parseInt(reader.nextLine());
      System.out.println("Enter number/s where you want the operations to be performed: ");
      num1=Integer.parseInt(reader.nextLine());
      num2=Integer.parseInt(reader.nextLine());
      
      if(op==1)
      {
        System.out.println(num1 & num2);
        System.out.println(num1 | num2);
        System.out.println(num1 ^ num2);
      }
      else if(op==2){
          System.out.println(~num2);
      }
      else if(op==3){
        //if(!num1)
        System.out.println("LOL0");
      }
      else{
        if(num1>num2 || num2<num1){
          System.out.println("LOL1");
        }
        if(num1>num2 && num2<num1){
          System.out.println("LOL2");
        }
      }
    }
}
