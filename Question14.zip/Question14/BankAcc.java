import java.util.Scanner;
class BankAcc{

	public int bal,acc_num,dep,with;
	public String name,acc_type;
	BankAcc()
	{
		name="Ankur";
		acc_num=10001000;
		acc_type="Savings";
		bal=4500;
	}
	
	public void Acc_Details()
	{
		Scanner reader=new Scanner (System.in);
		System.out.println("Enter your name: ");
		name=reader.nextLine();
		System.out.println("Enter your account type: ");
		acc_type=reader.nextLine();
		System.out.println("Enter your account number: ");
		acc_num=Integer.parseInt(reader.nextLine());
		System.out.println("Enter your balance: ");
		bal=Integer.parseInt(reader.nextLine());
		
	}
	
	public void Deposit()
	{
		Scanner reader=new Scanner (System.in);
		System.out.println("Enter the amount you want to deposit: ");
		dep=Integer.parseInt(reader.nextLine());
		bal=dep+bal;
	}
	public void Withdraw()
	{
		
		Scanner reader=new Scanner (System.in);
		if(bal>500)
		{
			System.out.println("Enter ammount to be withdrawn: ");
			with=Integer.parseInt(reader.nextLine());
			bal=bal-with;
		}
	}
	public void Show()
	{
		System.out.println("Transaction Complete");
		System.out.println("Name: "+name);
		System.out.println("Balance after transaction is: ");
		System.out.println(bal);
	}
}