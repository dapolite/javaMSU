import java.util.Scanner;
public class Question14{
	public static void main(String args[]){
		Scanner reader=new Scanner (System.in);
		int ch;
		BankAcc acc=new BankAcc();
		acc.Acc_Details();
		System.out.println("Enter your Choice \t1.Deposit \t2.Withdraw \t3.Show current balance \t4.Exit");
		ch=Integer.parseInt(reader.nextLine());

			switch(ch)
			{
			case 1:
				acc.Deposit();
				break;
			case 2:
				acc.Withdraw();
				break;
			case 3:
				acc.Show();
				break;
			case 4:
				System.exit(0);
				break;
			}

			acc.Show();
	}
}