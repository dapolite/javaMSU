import java.util.Scanner;
class Question6{
	public static void main(String[] args){
		int avg,sum;
		int tot=0;
		int s1,s2,s3,s4,s5,s6,s7;	
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter marks: ");
		s1=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s2=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s3=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s4=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s5=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s6=Integer.parseInt(reader.nextLine());
		System.out.println("Enter marks: ");
		s7=Integer.parseInt(reader.nextLine());
		tot=s1+s2+s3+s4+s5+s6+s7;
		avg=tot/7;
		System.out.println("Total Marks: "+tot);
		System.out.println("Average Marks: "+avg);
		if(avg>=85)
		{
			System.out.println("A+");
		}
		else if(avg<85 && avg>=60)
		{
			System.out.println("A+");
		}
		else if(avg<60 && avg>=50)
		{
			System.out.println("A+");
		}
		else if(avg<50 && avg>=40)
		{
			System.out.println("A+");
		}
		else
		{
			System.out.println("FAIL");
		}
	}
}