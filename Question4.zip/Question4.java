import java.util.Scanner;
class Question4{
	public static void main(String[] args){
		String car;
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter a character");
		car=reader.nextLine();
		char c=car.charAt(0);
		System.out.println("character: "+c);
		switch(c){
			case 'a':
			System.out.println("Entered char is a vowel");
			break;
			case 'e':
			System.out.println("Entered char is a vowel");
			break;
			case 'i':
			System.out.println("Entered char is a vowel");
			break;
			case 'o':
			System.out.println("Entered char is a vowel");
			break;
			case 'u':
			System.out.println("Entered char is a vowel");
			break;
			default:
			System.out.println("Entered char is not a vowel");
			break;
		}
	}
}