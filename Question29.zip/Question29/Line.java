package org.shapes;


public class Line{
	public Line(){}
	public void Show(){
		System.out.print("_______________________________________________");
		System.out.println("This is a line");
	}
}
