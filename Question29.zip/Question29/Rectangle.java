package org.shapes;
import java.util.Scanner;

public class Rectangle{
	public Rectangle(){}
	int area,l,b;
	public void Data(){
		Scanner reader=new Scanner(System.in);
		System.out.println("enter length and breadth");
		l=reader.nextInt();
		b=reader.nextInt();
	}

	public void Area(){
		area=l*b;
		System.out.println(area);
	}


}