class Question2{
public static void main(String[] args) {
	char ch='A';
	int x=1;
    	for(int i=0;i<5;i++) {
		System.out.println();
         for(int j=0;j<5-i;j++) {
             System.out.print(" ");
        }
	for(int j=0;j<=i;j++) {
	   if(i%2==0)
             System.out.print(" " + ch);
	   else
	     System.out.print(" " + x);
	ch++;
	x++;
        }
        System.out.println();  
    }

	
 }
}