import java.util.Scanner;
class Question9{
	public static void main(String[] args){
		Scanner reader=new Scanner(System.in);
		int i,n,tmp=0,j;
		System.out.println("Enter Array size: ");
		n=Integer.parseInt(reader.nextLine());
		int arr[]=new int[n];
		System.out.println("Enter Array elements: ");
		for(i=0;i<arr.length;i++)
		{	
			arr[i]=Integer.parseInt(reader.nextLine());
		}
		System.out.println("Array elements are: ");
		for(i=0;i<arr.length;i++)
		{	
			System.out.println(arr[i]);
		}
		for(i=0;i<arr.length;i++)
		{	
			for(j = i+1; j <arr.length; j++)
			if(arr[i]==arr[j])
			{
				tmp=arr[i];
			}
		}
		System.out.println("Repeated Array elements are: "+tmp);
		
	}
}