public class Question16 {

    public static void main(String[] args) {
        // TODO code application logic here
        MethodOverloadArea obj=new MethodOverloadArea();
        obj.Area(5);
        obj.Area(5,10);
        obj.Area(30.1,10.51);
        obj.Area(25.15);
    
   }
}