    class MethodOverloadArea{ 
        int area;
        double area2;
        
        public void Area(int l){
            area=l*l;
            System.out.println("Area of Square: "+area);
    }
        public void Area(int l,int b){
            area=l*b;
            System.out.println("Area of Rectangle: "+area);
    }
         public void Area(double b,double h){
            area2=1/2*(b*h);
            System.out.println("Area of Triangle: "+area2);
    }
         
         public void Area(double r){
            area2=3.14*r*r;
            System.out.println("Area of Circle: "+area2);
    }
         
        
 }