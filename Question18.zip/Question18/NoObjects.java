class NoObjects{   
	static int count=0;
    	NoObjects()
    	{
        	count++;
    	}
}