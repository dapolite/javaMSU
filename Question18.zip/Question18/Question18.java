public class Question18
{
    public static void main(String[] args) 
    {
        NoObjects obj1 = new NoObjects();
        NoObjects obj2 = new NoObjects();
        NoObjects obj3 = new NoObjects();
        NoObjects obj4 = new NoObjects();
        System.out.println("Number of objects created:"+NoObjects.count);
    }
}