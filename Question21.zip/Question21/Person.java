import java.util.Scanner;
class Person{
	public int bas_sal;
	String name;
	String dept;

	Person()
	{
		bas_sal=10000;
	}

	public void GetDetails()
	{
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter your name: ");
		name=reader.nextLine();
		System.out.println("Enter your basic salary: ");
		bas_sal=Integer.parseInt(reader.nextLine());
	}
}