public class Question21{
	public static void main(String args[]){
		Employee e1=new Employee();
		e1.GetDetails();
		e1.Show_bal();
		e1.Calc_DA();
		e1.Calc_HRA();
		e1.Calc_IT();
		e1.Calc_NetSal();

	}
}