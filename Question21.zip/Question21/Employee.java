import java.util.Scanner;
class Employee extends Person{
	int net,da,hra,ta,it;

	Employee()
	{
		ta=1000;
	}
	
	public void Show_bal()
	{
		System.out.println("Entered base Salary is: "+super.bas_sal);
	}

	public void Calc_DA()
	{
		da=(15*bas_sal)/100;
		System.out.println("DA is: "+da);
	}
	
	public void Calc_HRA()
	{
		hra=(20*bas_sal)/100;
		System.out.println("HRA is: "+hra);
	}
	
	public void Calc_IT()
	{
		net=bas_sal+da+hra-it;
		System.out.println("Net Salary  is: "+net);
	}

	public void Calc_NetSal()
	{
		it=(10*bas_sal+da+hra+ta)/100;
		System.out.println("IT is: "+it);
	}
	
	
}