class Sum implements Numbers{
	int res;
	int num1,num2;
	public int Process(int x,int y){
		res=x+y;
		return res;
	}
}