interface Numbers{
	public int Process(int x,int y);
} 