public class Question25{
	public static void main(String args[]){
		Sum s=new Sum();
		Average a=new Average();
		System.out.println(s.Process(5,10));
		System.out.println(a.Process(5,10));
	}
}