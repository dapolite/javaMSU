class Average implements Numbers{
	int avg;
	public int Process(int x,int y){
		avg=(x+y)/2;
		return avg;
	}
}