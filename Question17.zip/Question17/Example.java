class Example{
   Example(){
      System.out.println("Default constructor");
   }

   Example(int i, int j){
      System.out.println("constructor with Two parameters");
   }

   Example(int i, int j, int k){
      System.out.println("constructor with Three parameters");	      
   }
}