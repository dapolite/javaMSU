public class Question17{

   public static void main(String args[]){

      Example obj = new Example();

      Example obj2 = new Example(12, 12);

      Example obj3 = new Example(1, 2, 13);

   }
}