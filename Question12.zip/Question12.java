import java.util.Scanner;
class Question12{
	public static void main(String[] args){
		Scanner reader=new Scanner(System.in);
		int i,n,j;
		System.out.println("Enter Array size: ");
		n=Integer.parseInt(reader.nextLine());
		int arr[]=new int[n];
		int brr[]=new int[6];
		System.out.println("Enter Array elements: ");
		for(i=0;i<arr.length;i++)
		{	
			arr[i]=Integer.parseInt(reader.nextLine());
		}
		System.out.println("Array elements are: ");
		for(i=0;i<arr.length;i++)
		{	
			System.out.println(arr[i]);
		}
		for(i=arr.length-1,j=0;i>=5;i--,j++)
		{	
			brr[j]=arr[i];
		}
		System.out.println("New Array elements are: ");
		for(i=0;i<brr.length;i++)
		{	
			System.out.println(brr[i]);
		}
		
	}
}

