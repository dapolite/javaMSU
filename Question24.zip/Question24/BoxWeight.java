class BoxWeight extends Box{
	int weight;
	int vol;

	BoxWeight()
	{
		weight=100;
	}

	public void Volume(){
			vol=height*width*depth;
			System.out.println("Volume of the Box is "+vol);
		} 
	public void Weight(){
			System.out.println("Weight of the Box is "+weight);
		}
}