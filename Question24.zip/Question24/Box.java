class Box{
	int width,height,depth;
	
	Box()
	{
		width=5;
		height=10;
		depth=15;
	}
}