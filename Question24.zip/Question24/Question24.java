public class Question24{
	public static void main(String args[]){
		BoxWeight obj=new BoxWeight();
		obj.Volume();
		obj.Weight();
	}
}