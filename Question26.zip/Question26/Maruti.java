import java.util.Scanner;
class Maruti implements Vehicle,Car{
	int mil,fuel,range;
	public void getMilage(){
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter the vehicle milage: ");
		mil=Integer.parseInt(reader.nextLine());
	}

	public void getFuel(){
		Scanner reader=new Scanner(System.in);
		System.out.println("Enter the vehicle Fuel: ");
		fuel=Integer.parseInt(reader.nextLine());
	}
	
	public void CalcRange(){
		range=fuel*mil;
		System.out.println("The range of the vehicle is: "+range);
	}
}