public class Question26{
	public static void main(String args[]){
		Maruti m=new Maruti();
		m.getFuel();
		m.getMilage();
		m.CalcRange();
	}
}