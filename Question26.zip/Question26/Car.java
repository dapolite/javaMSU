interface Car{
	public void getFuel();
}