
interface Vehicle{
	public void getMilage();
}