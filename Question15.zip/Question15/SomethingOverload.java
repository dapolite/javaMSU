

class SomethingOverload{ 
        int res;
        float reso;
        double reson;
        
        public void Add(int num1,int num2){
            	res=num1+num2;
            	System.out.println("Addition of two intigers: "+res);
    	}
        public void Add(int num1,int num2,int num3){
            	res=num1+num2+num3;
            	System.out.println("Addition of three intigers: "+res);
    	}
         public void Add(float num1,float num2){
            reso=num1+num2;
            System.out.println("Addition of two float: "+reso);
    	}
         
         public void Add(double num1,double num2){
            reson=num1+num2;
            System.out.println("Addition of two double: "+reson);
    	}
         
        
 }