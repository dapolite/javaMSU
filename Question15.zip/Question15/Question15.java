public class Question15{
    public static void main(String[] args) {
        SomethingOverload obj=new SomethingOverload();
        obj.Add(5,10);
        obj.Add(5,10,25);
        obj.Add(5.11,10.77);
        obj.Add(5.7895654,10.4566624);
    
   }
    
}